<?php
/*
 Plugin Name: Screeyn Custom Post Types
 Plugin URI: http://themeforest.net/user/screeynthemes
 Description: Custom post types for use in the Screeyn WooCommerce theme. Please install this plugin to fully utilize the Screeyn theme.
 Author: screeyn Themes
 Author URI: http://themeforest.net/user/screeynthemes
 Version: 1.0
 */

/**
 * Homepage items
 */
function screeyn_homepage_custom_init() {

    $screeyn_homepageitem_labels = array(
        'name'                  => esc_html_x('Homepage items', 'post type general name', 'screeyn'),
        'singular_name'         => esc_html_x('Homepage item', 'post type singular name', 'screeyn'),
        'add_new'               => esc_html_x('Add new', 'homepage item', 'screeyn'),
        'add_new_item'          => esc_html__('Add new', 'screeyn'),
        'edit_item'             => esc_html__('Edit item', 'screeyn'),
        'new_item'              => esc_html__('New item', 'screeyn'),
        'view_item'             => esc_html__('View item', 'screeyn'),
        'search_items'          => esc_html__('Search items', 'screeyn'),
        'not_found'             => esc_html__('No items found', 'screeyn'),
        'not_found_in_trash'    => esc_html__('No items found in trash', 'screeyn'),
        'menu_name'             => esc_html__('Homepage', 'screeyn')
    );

    $screeyn_homepageitem_args = array(
        'labels'                => $screeyn_homepageitem_labels,
        'exclude_from_search'   => true,
        'show_in_nav_menus'     => false,
        'public'                => false,
        'menu_icon'             => 'dashicons-admin-home',
        'menu_position'         => 3,
        'publicly_queryable'    => false,
        'show_ui'               => true,
        'show_in_menu'          => true,
        'query_var'             => true,
        'rewrite'               => true,
        'capability_type'       => 'post',
        'hierarchical'          => false,
        'supports'              => array('title','editor','thumbnail')
    );

    register_post_type( 'homepageitem', $screeyn_homepageitem_args );

}
add_action( 'init', 'screeyn_homepage_custom_init' );

/**
 * Frequently Asked Questions
 */
function screeyn_faq_custom_init() {

    $screeyn_faqitem_labels = array(
        'name'                  => esc_html_x('Faq items', 'post type general name', 'screeyn'),
        'singular_name'         => esc_html_x('Faq item', 'post type singular name', 'screeyn'),
        'add_new'               => esc_html_x('Add new', 'Faq item', 'screeyn'),
        'add_new_item'          => esc_html__('Add new', 'screeyn'),
        'edit_item'             => esc_html__('Edit item', 'screeyn'),
        'new_item'              => esc_html__('New item', 'screeyn'),
        'view_item'             => esc_html__('View item', 'screeyn'),
        'search_items'          => esc_html__('Search items', 'screeyn'),
        'not_found'             => esc_html__('No items found', 'screeyn'),
        'not_found_in_trash'    => esc_html__('No items found in trash', 'screeyn'),
        'menu_name'             => esc_html__('FAQ', 'screeyn')
    );

    $screeyn_faqitem_args = array(
        'labels'                => $screeyn_faqitem_labels,
        'exclude_from_search'   => true,
        'show_in_nav_menus'     => false,
        'public'                => false,
        'menu_icon'             => 'dashicons-editor-help',
        'menu_position'         => 3,
        'publicly_queryable'    => false,
        'show_ui'               => true,
        'show_in_menu'          => true,
        'query_var'             => true,
        'rewrite'               => true,
        'capability_type'       => 'post',
        'hierarchical'          => false,
        'supports'              => array('title','editor','thumbnail')
    );

    register_post_type( 'our-faq', $screeyn_faqitem_args );

    $screeyn_faqitem_category_labels = array(
        'name'                  => esc_html_x( 'Categories', 'taxonomy general name', 'screeyn' ),
        'singular_name'         => esc_html_x( 'Category', 'taxonomy singular name', 'screeyn' ),
        'search_items'          => esc_html__( 'Search Categories', 'screeyn' ),
        'all_items'             => esc_html__( 'All Categories', 'screeyn' ),
        'parent_item'           => esc_html__( 'Parent Category', 'screeyn' ),
        'parent_item_colon'     => esc_html__( 'Parent Category:', 'screeyn' ),
        'edit_item'             => esc_html__( 'Edit Categories', 'screeyn' ),
        'update_item'           => esc_html__( 'Update Category', 'screeyn' ),
        'add_new_item'          => esc_html__( 'Add New Category', 'screeyn' ),
        'new_item_name'         => esc_html__( 'New Category Name', 'screeyn' ),
    );

    register_taxonomy( 'faq-categories', array('our-faq'), array(
        'hierarchical'          => true,
        'labels'                => $screeyn_faqitem_category_labels,
        'show_ui'               => true,
        'query_var'             => true,
        'rewrite'               => array( 'slug' => 'faq-categories' ),
    ));

}
add_action( 'init', 'screeyn_faq_custom_init' );

/**
 * Press
 */
function screeyn_press_custom_init() {

    $screeyn_press_labels = array(
        'name'                  => esc_html_x('Press', 'post type general name', 'screeyn'),
        'singular_name'         => esc_html_x('Press', 'post type singular name', 'screeyn'),
        'add_new'               => esc_html_x('Add New', 'Press item', 'screeyn'),
        'add_new_item'          => esc_html__('Add New', 'screeyn'),
        'edit_item'             => esc_html__('Change Item', 'screeyn'),
        'new_item'              => esc_html__('New Item', 'screeyn'),
        'view_item'             => esc_html__('View Item', 'screeyn'),
        'search_items'          => esc_html__('Search Item', 'screeyn'),
        'not_found'             => esc_html__('No Items Found', 'screeyn'),
        'not_found_in_trash'    => esc_html__('No Items Found in Trash', 'screeyn'),
        'menu_name'             => esc_html__('Press', 'screeyn'),
    );

    $screeyn_press_args = array(
        'labels'                => $screeyn_press_labels,
        'exclude_from_search'   => true,
        'show_in_nav_menus'     => false,
        'menu_icon'             => 'dashicons-format-aside',
        'menu_position'         => 1,
        'publicly_queryable'    => false,
        'show_ui'               => true,
        'show_in_menu'          => true,
        'query_var'             => true,
        'rewrite'               => true,
        'capability_type'       => 'post',
        'has_archive'           => true,
        'hierarchical'          => false,
        'menu_position'         => null,
        'supports'              => array('title','editor','thumbnail')
    );

    register_post_type( 'our-press', $screeyn_press_args );

}
add_action( 'init', 'screeyn_press_custom_init' );

/**
 * Testimonials
 */
function screeyn_Testimonials_custom_init() {

    $screeyn_testimonial_labels = array(
        'name'                  => esc_html_x('Testimonials', 'post type general name', 'screeyn'),
        'singular_name'         => esc_html_x('Testimonial', 'post type singular name', 'screeyn'),
        'add_new'               => esc_html_x('Add new', 'Testimonial', 'screeyn'),
        'add_new_item'          => esc_html__('Add Testimonial', 'screeyn'),
        'edit_item'             => esc_html__('Edit Testimonial', 'screeyn'),
        'new_item'              => esc_html__('New Testimonial', 'screeyn'),
        'view_item'             => esc_html__('View Testimonial', 'screeyn'),
        'search_items'          => esc_html__('Search Testimonials', 'screeyn'),
        'not_found'             => esc_html__('No Testimonials gevonden', 'screeyn'),
        'not_found_in_trash'    => esc_html__('No Testimonials found in trash', 'screeyn'),
        'menu_name'             => esc_html__('Testimonials', 'screeyn'),
    );

    $screeyn_testimonial_args = array(
        'labels'                => $screeyn_testimonial_labels,
        'exclude_from_search'   => true,
        'show_in_nav_menus'     => false,
        'menu_icon'             => 'dashicons-format-chat',
        'menu_position'         => 1,
        'publicly_queryable'    => false,
        'show_ui'               => true,
        'show_in_menu'          => true,
        'query_var'             => true,
        'rewrite'               => true,
        'capability_type'       => 'post',
        'has_archive'           => true,
        'hierarchical'          => false,
        'menu_position'         => null,
        'supports'              => array('title','editor','thumbnail')
    );

    register_post_type( 'our-testimonials', $screeyn_testimonial_args );

}
add_action( 'init', 'screeyn_Testimonials_custom_init' );

/**
 * Features
 */
function screeyn_features_custom_init() {

    $screeyn_feature_labels = array(
        'name'                  => esc_html_x('Features', 'post type general name', 'screeyn'),
        'singular_name'         => esc_html_x('Feature', 'post type singular name', 'screeyn'),
        'add_new'               => esc_html_x('Add new', 'Feature', 'screeyn'),
        'add_new_item'          => esc_html__('Add Feature', 'screeyn'),
        'edit_item'             => esc_html__('Edit Feature', 'screeyn'),
        'new_item'              => esc_html__('New Feature', 'screeyn'),
        'view_item'             => esc_html__('View Feature', 'screeyn'),
        'search_items'          => esc_html__('Search Features', 'screeyn'),
        'not_found'             => esc_html__('No Features found', 'screeyn'),
        'not_found_in_trash'    => esc_html__('No Features found in trash', 'screeyn'),
        'menu_name'             => esc_html__('Features', 'screeyn'),
    );

    $screeyn_feature_args = array(
        'labels'                => $screeyn_feature_labels,
        'exclude_from_search'   => true,
        'show_in_nav_menus'     => false,
        'menu_icon'             => 'dashicons-editor-ul',
        'menu_position'         => 1,
        'publicly_queryable'    => false,
        'show_ui'               => true,
        'show_in_menu'          => true,
        'query_var'             => true,
        'rewrite'               => true,
        'capability_type'       => 'post',
        'has_archive'           => true,
        'hierarchical'          => false,
        'menu_position'         => null,
        'supports'              => array('title','editor','thumbnail')
    );

    register_post_type( 'our-features', $screeyn_feature_args );

}
add_action( 'init', 'screeyn_features_custom_init' );

/**
 * Gallery
 */
function screeyn_gallery_custom_init() {

    $gallery_labels = array(
        'name'                  => esc_html_x('Gallery', 'post type general name', 'screeyn'),
        'singular_name'         => esc_html_x('Slide', 'post type singular name', 'screeyn'),
        'add_new'               => esc_html_x('Add New', 'Gallery', 'screeyn'),
        'add_new_item'          => esc_html__('Add Slide', 'screeyn'),
        'edit_item'             => esc_html__('Edit Slide', 'screeyn'),
        'new_item'              => esc_html__('New Slide', 'screeyn'),
        'view_item'             => esc_html__('View Slide', 'screeyn'),
        'search_items'          => esc_html__('Search Gallery', 'screeyn'),
        'not_found'             => esc_html__('No Slide Found', 'screeyn'),
        'not_found_in_trash'    => esc_html__('No Slides Found In Trash', 'screeyn'),
        'parent_item_colon'     => '',
        'menu_name'             => esc_html__('Gallery', 'screeyn')
    );

    $gallery_args = array(
        'labels'                => $gallery_labels,
        'exclude_from_search'   => true,
        'show_in_nav_menus'     => false,
        'menu_icon'             => 'dashicons-images-alt2',
        'menu_position'         => 1,
        'publicly_queryable'    => true,
        'show_ui'               => true,
        'show_in_menu'          => true,
        'query_var'             => true,
        'rewrite'               => true,
        'capability_type'       => 'post',
        'has_archive'           => true,
        'hierarchical'          => false,
        'menu_position'         => null,
        'supports'              => array('title','thumbnail', 'editor')
    );

    register_post_type('screeyn-featured',$gallery_args);

}
add_action('init', 'screeyn_gallery_custom_init');